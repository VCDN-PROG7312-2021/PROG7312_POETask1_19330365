﻿
namespace DeweyDecimalSystem
{
    partial class ReplacingBooksFRM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstRandomNumbers = new System.Windows.Forms.ListBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnBegin = new System.Windows.Forms.Button();
            this.lbInfo = new System.Windows.Forms.Label();
            this.lstNumber = new System.Windows.Forms.ListBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 19.8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(251, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Replacing Books";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lstRandomNumbers
            // 
            this.lstRandomNumbers.AllowDrop = true;
            this.lstRandomNumbers.BackColor = System.Drawing.Color.DarkOrange;
            this.lstRandomNumbers.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lstRandomNumbers.ForeColor = System.Drawing.Color.Black;
            this.lstRandomNumbers.FormattingEnabled = true;
            this.lstRandomNumbers.ItemHeight = 31;
            this.lstRandomNumbers.Location = new System.Drawing.Point(12, 112);
            this.lstRandomNumbers.Name = "lstRandomNumbers";
            this.lstRandomNumbers.Size = new System.Drawing.Size(296, 438);
            this.lstRandomNumbers.TabIndex = 12;
            this.lstRandomNumbers.Click += new System.EventHandler(this.lstRandomNumbers_Click);
            this.lstRandomNumbers.SelectedIndexChanged += new System.EventHandler(this.lstRandomNumbers_SelectedIndexChanged);
            this.lstRandomNumbers.DragDrop += new System.Windows.Forms.DragEventHandler(this.lstRandomNumbers_DragDrop);
            this.lstRandomNumbers.DragEnter += new System.Windows.Forms.DragEventHandler(this.lstRandomNumbers_DragEnter);
            this.lstRandomNumbers.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lstRandomNumbers_MouseDown);
            this.lstRandomNumbers.MouseEnter += new System.EventHandler(this.lstRandomNumbers_MouseEnter);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSubmit.Location = new System.Drawing.Point(251, 586);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(102, 41);
            this.btnSubmit.TabIndex = 13;
            this.btnSubmit.Text = "Check";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnBegin
            // 
            this.btnBegin.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBegin.Location = new System.Drawing.Point(359, 586);
            this.btnBegin.Name = "btnBegin";
            this.btnBegin.Size = new System.Drawing.Size(102, 41);
            this.btnBegin.TabIndex = 14;
            this.btnBegin.Text = "Begin";
            this.btnBegin.UseVisualStyleBackColor = true;
            this.btnBegin.Click += new System.EventHandler(this.btnBegin_Click);
            // 
            // lbInfo
            // 
            this.lbInfo.AutoSize = true;
            this.lbInfo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbInfo.Location = new System.Drawing.Point(531, 563);
            this.lbInfo.Name = "lbInfo";
            this.lbInfo.Size = new System.Drawing.Size(97, 20);
            this.lbInfo.TabIndex = 15;
            this.lbInfo.Text = "How To Play?";
            this.lbInfo.Click += new System.EventHandler(this.lbInfo_Click);
            // 
            // lstNumber
            // 
            this.lstNumber.AllowDrop = true;
            this.lstNumber.BackColor = System.Drawing.Color.Orange;
            this.lstNumber.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lstNumber.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lstNumber.FormattingEnabled = true;
            this.lstNumber.ItemHeight = 31;
            this.lstNumber.Location = new System.Drawing.Point(443, 112);
            this.lstNumber.Name = "lstNumber";
            this.lstNumber.Size = new System.Drawing.Size(296, 438);
            this.lstNumber.TabIndex = 16;
            this.lstNumber.DragDrop += new System.Windows.Forms.DragEventHandler(this.lstNumber_DragDrop);
            this.lstNumber.DragEnter += new System.Windows.Forms.DragEventHandler(this.lstNumber_DragEnter);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRemove.Location = new System.Drawing.Point(314, 305);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(123, 41);
            this.btnRemove.TabIndex = 17;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // ReplacingBooksFRM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(756, 659);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.lstNumber);
            this.Controls.Add(this.lbInfo);
            this.Controls.Add(this.btnBegin);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lstRandomNumbers);
            this.Controls.Add(this.label1);
            this.Name = "ReplacingBooksFRM";
            this.ShowIcon = false;
            this.Text = "ReplacingBooksFRM";
            this.Load += new System.EventHandler(this.ReplacingBooksFRM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstRandomNumbers;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnBegin;
        private System.Windows.Forms.Label lbInfo;
        private System.Windows.Forms.ListBox lstNumber;
        private System.Windows.Forms.Button btnRemove;
    }
}

//Cody Smith
//19330365
//PROG7312_POE_TASK1
//________________________________________________________________________________________
//    .Code attribution
//    ._______________________________________________________________________________________
//    .BOOLEAN
//    .Link: false, B., 2021. Bool list check if every item in list is false. [online] Stack Overflow. Available at: <https://stackoverflow.com/questions/22618284/bool-list-check-if-every-item-in-list-is-false> [Accessed 30 September 2021].
//    .-__________________________________________________________________________________
//    .MESSAGEBOX
//    .C-sharpcorner.com. 2021. C# Message Box. [online] Available at: <https://www.c-sharpcorner.com/UploadFile/mahesh/understanding-message-box-in-windows-forms-using-C-Sharp/> [Accessed 30 September 2021].
//    ._______________________________________________________________________________________________
//    .ARRAYLIST
//    .Link: C-sharpcorner.com. 2021. Sort Array in Ascending Order in Windows Store App. [online] Available at: <https://www.c-sharpcorner.com/UploadFile/8ea152/sort-array-in-ascending-order-in-windows-store-app/> [Accessed 30 September 2021].
//    .________________________________________________________________________________________________
//    .LinkedList part 1/2
//    .Link:https://youtu.be/vEkns_e5HSs?list=PL480DYS-b_kfaBw2kLT_Ne1h5bhTKxgiD
//    .____________________________________________________________________________________