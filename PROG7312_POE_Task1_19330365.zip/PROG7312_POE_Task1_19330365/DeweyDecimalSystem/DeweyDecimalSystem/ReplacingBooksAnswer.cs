﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeweyDecimalSystem
{
    class ReplacingBooksAnswer
    {




        ////////List<int> numList = new List<int>();

        ////////public List<int> NumList { get => numList; set => numList = value; }

        ////////public ReplacingBooksAnswer(List<int> numList)
        ////////{
        ////////    this.NumList = numList; 
        ////////}

        ////////public void SortOrder()
        ////////{

        ////////}
        ////////public ReplacingBooksAnswer()
        ////////{

        ////////}


    }
}
