﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeweyDecimalSystem
{

    public partial class ReplacingBooksFRM : Form
    {
        Random random = new Random();

        //Array Lists
        private String[] listCallNumbers = new String[10];
        private String[] listCorrect = new String[10];
        private String[] listNumbers = new String[10];
        private String[] listLetters = new String[10];
        private String[] listArranged = new String[10];

        public ReplacingBooksFRM()
        {
            InitializeComponent();
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lstRandomNumbers_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //To determine if the user results matches with the systems
            if(listArranged == listCorrect == true)
            {
                MessageBox.Show("Congratulations!!! You have won!");
            }
            else
            {
                MessageBox.Show("YOU LOSE... Try again?");
            }
            
            
        }

        int intClicks;

        public string[] ListArranged { get => listArranged; set => listArranged = value; }

        private void btnBegin_Click(object sender, EventArgs e)
        {
            lstRandomNumbers.Items.Clear();
            lstNumber.Items.Clear();
            SetString();
            DeweyDisplay();

            if (intClicks++.Equals(5))
            {
                
                string message = "Congratulations you have Achieved a badge, would you like to go on?";
                string title = "Badge Achieved!";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.No)
                {
                    this.Close();
                }
            }return;


            
        }

        private void ReplacingBooksFRM_Load(object sender, EventArgs e)
        {

        }

        private void lbInfo_Click(object sender, EventArgs e)
        {//Messagebox to learn how to play if the user is unsure
            MessageBox.Show("\t\tHow To Play\t\t" +
                "\n_________________________________________________________________________________________" + 
                "\nTo play all you need to do is drag the numbers that appear in " +
                "\nthe First box over to the second one in ascending order.");
        }



        public void SetString()
        {
            

            //generate random numbers
            for (int i = 0; i < listNumbers.Length; i++) 
            {
                //Random List being set
                string randomList = string.Format("{0:000.###}", random.NextDouble() * 1000);
                listNumbers[i] = randomList;

                //Generating Random Letters
                var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                var varChars = new char[3];

                for (int x = 0; x < varChars.Length; x++)
                {
                    varChars[x] = letters[random.Next(letters.Length)];
                }

                var fnlString = new String(varChars);
                listLetters[i] = fnlString;

            }

            //Setting the Final Call Number
            for (int i = 0; i < listCallNumbers.Length; i++)
            {
                string fnlNumbers = listNumbers[i] + " " + listLetters[i];
                listCallNumbers[i] = (fnlNumbers);
                listCorrect[i] = listCallNumbers[i]; 
                
            }
            
                Array.Sort(listCorrect, StringComparer.Ordinal);
            
            
            
        }


        public void DeweyDisplay()
        {
            for(int i=0; i < listCallNumbers.Length; i++)
            {
                lstRandomNumbers.Items.Add(listCallNumbers[i]);
            }
        }


        private void lstRandomNumbers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        //Drag and drop from listbox to listbox
        private void lstRandomNumbers_MouseDown(object sender, MouseEventArgs e)
        {
            lstRandomNumbers.DoDragDrop(lstRandomNumbers.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void lstNumber_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Move;
            else
                e.Effect = DragDropEffects.None;
        }

        private void lstNumber_DragDrop(object sender, DragEventArgs e)
        {
            lstNumber.Items.Add(e.Data.GetData(DataFormats.Text).ToString());
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstRandomNumbers.Items.Remove(lstRandomNumbers.SelectedItem);
            lstNumber.Items.Remove(lstNumber.SelectedItem);
        }

        private void lstRandomNumbers_DragDrop(object sender, DragEventArgs e)
        {
            lstRandomNumbers.Items.Add(e.Data.GetData(DataFormats.Text).ToString());
        }

        private void lstRandomNumbers_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void lstRandomNumbers_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Move;
            else
                e.Effect = DragDropEffects.None;
        }

        

        public Boolean isArranged()
        {
            bool isEqual = Enumerable.SequenceEqual(listCorrect, listArranged);
            if (isEqual)
            {
                return true;
            }
            else return false;
        }
    }
    
}
